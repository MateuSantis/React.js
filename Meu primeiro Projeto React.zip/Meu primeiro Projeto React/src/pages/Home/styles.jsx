import styled from "styled-components";

export const AddButton = styled.button `
background-color: #6cf000;
color: #000;
height: 35px;
`